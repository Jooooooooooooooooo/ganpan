﻿using System;
using GrapeCity.ActiveReports.SectionReportModel;
namespace MCS.PrintBoard
{
	public partial class OfflinePrintBoard_GsrmSize
    {
  protected override void Dispose(bool disposing)
	{
	if (disposing)
	  {
	  }
	base.Dispose(disposing);
	}
	  
		#region ActiveReports Designer generated code
	   
	   
		
		public void InitializeComponent()
		{
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(OfflinePrintBoard_GsrmSize));
            this.txtTOTAL_QUANTITY = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtCARRIER_ID = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtMADE_BY = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtDESCRIPTION = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtINSPECTION_FLAG = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtWO_QUANTITY1 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtTOTAL_SEQ_NO = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtMODEL_SUFFIX1 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtWORKER_ORDER1 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.label1 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.label2 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.label3 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.label4 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.label5 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.label6 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.label7 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.label8 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.label9 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.label10 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.label12 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.label13 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.label15 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.txtPrintedDate = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.label17 = new GrapeCity.ActiveReports.SectionReportModel.Label();
            this.txtWO_QUANTITY2 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.textBox4 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.textBox5 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtWO_QUANTITY3 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.textBox9 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.textBox10 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtWO_QUANTITY4 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.textBox14 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.textBox15 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtWO_QUANTITY5 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.textBox19 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.textBox20 = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.barcode = new GrapeCity.ActiveReports.SectionReportModel.Barcode();
            this.txtLOCATOR_GROUP = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtLINE = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtPART_NO = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.line1 = new GrapeCity.ActiveReports.SectionReportModel.Line();
            this.shape1 = new GrapeCity.ActiveReports.SectionReportModel.Shape();
            this.shape2 = new GrapeCity.ActiveReports.SectionReportModel.Shape();
            this.line2 = new GrapeCity.ActiveReports.SectionReportModel.Line();
            this.line3 = new GrapeCity.ActiveReports.SectionReportModel.Line();
            this.line4 = new GrapeCity.ActiveReports.SectionReportModel.Line();
            this.line5 = new GrapeCity.ActiveReports.SectionReportModel.Line();
            this.line6 = new GrapeCity.ActiveReports.SectionReportModel.Line();
            this.line8 = new GrapeCity.ActiveReports.SectionReportModel.Line();
            this.line9 = new GrapeCity.ActiveReports.SectionReportModel.Line();
            this.line10 = new GrapeCity.ActiveReports.SectionReportModel.Line();
            this.line11 = new GrapeCity.ActiveReports.SectionReportModel.Line();
            this.line12 = new GrapeCity.ActiveReports.SectionReportModel.Line();
            this.line13 = new GrapeCity.ActiveReports.SectionReportModel.Line();
            this.txtSheetID = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.txtPST = new GrapeCity.ActiveReports.SectionReportModel.TextBox();
            this.Detail = new GrapeCity.ActiveReports.SectionReportModel.Detail();
            ((System.ComponentModel.ISupportInitialize)(this.txtTOTAL_QUANTITY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCARRIER_ID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMADE_BY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDESCRIPTION)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtINSPECTION_FLAG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWO_QUANTITY1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTOTAL_SEQ_NO)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMODEL_SUFFIX1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWORKER_ORDER1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrintedDate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.label17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWO_QUANTITY2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWO_QUANTITY3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWO_QUANTITY4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWO_QUANTITY5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLOCATOR_GROUP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLINE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPART_NO)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSheetID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPST)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // txtTOTAL_QUANTITY
            // 
            this.txtTOTAL_QUANTITY.CanGrow = false;
            this.txtTOTAL_QUANTITY.DataField = "TOTAL_QUANTITY";
            this.txtTOTAL_QUANTITY.Height = 0.2F;
            this.txtTOTAL_QUANTITY.Left = 0.2719725F;
            this.txtTOTAL_QUANTITY.Name = "txtTOTAL_QUANTITY";
            this.txtTOTAL_QUANTITY.Style = "background-color: Transparent; font-size: 12pt; font-weight: bold; text-align: ce" +
    "nter; vertical-align: middle";
            this.txtTOTAL_QUANTITY.Text = "TOTAL_QUANTITY";
            this.txtTOTAL_QUANTITY.Top = 1.069929F;
            this.txtTOTAL_QUANTITY.Width = 1.052756F;
            // 
            // txtCARRIER_ID
            // 
            this.txtCARRIER_ID.DataField = "CARRIER_ID";
            this.txtCARRIER_ID.Height = 0.2468503F;
            this.txtCARRIER_ID.Left = 0.2404764F;
            this.txtCARRIER_ID.Name = "txtCARRIER_ID";
            this.txtCARRIER_ID.Style = "background-color: Transparent; font-size: 12pt; font-weight: bold; text-align: ce" +
    "nter; vertical-align: middle";
            this.txtCARRIER_ID.Text = "CARRIER_ID";
            this.txtCARRIER_ID.Top = 2.121504F;
            this.txtCARRIER_ID.Width = 1.079921F;
            // 
            // txtMADE_BY
            // 
            this.txtMADE_BY.CanGrow = false;
            this.txtMADE_BY.DataField = "MADE_BY";
            this.txtMADE_BY.Height = 0.2570866F;
            this.txtMADE_BY.Left = 0.2703975F;
            this.txtMADE_BY.Name = "txtMADE_BY";
            this.txtMADE_BY.OutputFormat = resources.GetString("txtMADE_BY.OutputFormat");
            this.txtMADE_BY.Style = "background-color: Transparent; font-size: 12pt; font-weight: bold; text-align: ce" +
    "nter; vertical-align: middle; ddo-font-vertical: true";
            this.txtMADE_BY.Text = "MADE_BY";
            this.txtMADE_BY.Top = 1.593551F;
            this.txtMADE_BY.Width = 1.029528F;
            // 
            // txtDESCRIPTION
            // 
            this.txtDESCRIPTION.CanGrow = false;
            this.txtDESCRIPTION.DataField = "DESCRIPTION";
            this.txtDESCRIPTION.Height = 0.2625981F;
            this.txtDESCRIPTION.Left = 1.334964F;
            this.txtDESCRIPTION.Name = "txtDESCRIPTION";
            this.txtDESCRIPTION.OutputFormat = resources.GetString("txtDESCRIPTION.OutputFormat");
            this.txtDESCRIPTION.Style = "background-color: Transparent; font-size: 14.25pt; font-weight: bold; text-align:" +
    " center; vertical-align: middle";
            this.txtDESCRIPTION.Text = "DESCRIPTION";
            this.txtDESCRIPTION.Top = 1.008906F;
            this.txtDESCRIPTION.Width = 3.041733F;
            // 
            // txtINSPECTION_FLAG
            // 
            this.txtINSPECTION_FLAG.CanGrow = false;
            this.txtINSPECTION_FLAG.DataField = "INSPECTION_FLAG";
            this.txtINSPECTION_FLAG.Height = 0.2F;
            this.txtINSPECTION_FLAG.Left = 1.353467F;
            this.txtINSPECTION_FLAG.Name = "txtINSPECTION_FLAG";
            this.txtINSPECTION_FLAG.OutputFormat = resources.GetString("txtINSPECTION_FLAG.OutputFormat");
            this.txtINSPECTION_FLAG.Style = "background-color: Transparent; font-size: 11pt; font-weight: bold; text-align: ce" +
    "nter; vertical-align: middle; ddo-char-set: 1";
            this.txtINSPECTION_FLAG.Text = "INSPECTION_FLAG";
            this.txtINSPECTION_FLAG.Top = 2.088039F;
            this.txtINSPECTION_FLAG.Width = 1.343307F;
            // 
            // txtWO_QUANTITY1
            // 
            this.txtWO_QUANTITY1.CanGrow = false;
            this.txtWO_QUANTITY1.DataField = "WO_QUANTITY1";
            this.txtWO_QUANTITY1.Height = 0.1811024F;
            this.txtWO_QUANTITY1.Left = 2.743232F;
            this.txtWO_QUANTITY1.Name = "txtWO_QUANTITY1";
            this.txtWO_QUANTITY1.OutputFormat = resources.GetString("txtWO_QUANTITY1.OutputFormat");
            this.txtWO_QUANTITY1.Style = "background-color: Transparent; font-size: 9.75pt; font-weight: bold; text-align: " +
    "center; vertical-align: middle";
            this.txtWO_QUANTITY1.Text = "WO_QUANTITY1";
            this.txtWO_QUANTITY1.Top = 1.693551F;
            this.txtWO_QUANTITY1.Width = 0.3996062F;
            // 
            // txtTOTAL_SEQ_NO
            // 
            this.txtTOTAL_SEQ_NO.DataField = "TOTAL_SEQ_NO";
            this.txtTOTAL_SEQ_NO.Height = 0.3354331F;
            this.txtTOTAL_SEQ_NO.Left = 1.557404F;
            this.txtTOTAL_SEQ_NO.Name = "txtTOTAL_SEQ_NO";
            this.txtTOTAL_SEQ_NO.OutputFormat = resources.GetString("txtTOTAL_SEQ_NO.OutputFormat");
            this.txtTOTAL_SEQ_NO.Style = "background-color: Transparent; font-size: 15.75pt; font-weight: bold; text-align:" +
    " center; vertical-align: middle; ddo-font-vertical: none";
            this.txtTOTAL_SEQ_NO.Text = "TOTAL_SEQ_NO";
            this.txtTOTAL_SEQ_NO.Top = 0.4864648F;
            this.txtTOTAL_SEQ_NO.Width = 2.834252F;
            // 
            // txtMODEL_SUFFIX1
            // 
            this.txtMODEL_SUFFIX1.CanGrow = false;
            this.txtMODEL_SUFFIX1.DataField = "MODEL_SUFFIX1";
            this.txtMODEL_SUFFIX1.Height = 0.1811024F;
            this.txtMODEL_SUFFIX1.Left = 3.208184F;
            this.txtMODEL_SUFFIX1.Name = "txtMODEL_SUFFIX1";
            this.txtMODEL_SUFFIX1.OutputFormat = resources.GetString("txtMODEL_SUFFIX1.OutputFormat");
            this.txtMODEL_SUFFIX1.Style = "background-color: Transparent; font-size: 8pt; font-weight: bold; text-align: cen" +
    "ter; vertical-align: middle; ddo-char-set: 1";
            this.txtMODEL_SUFFIX1.Text = "MODEL_SUFFIX1";
            this.txtMODEL_SUFFIX1.Top = 1.685677F;
            this.txtMODEL_SUFFIX1.Width = 1.315355F;
            // 
            // txtWORKER_ORDER1
            // 
            this.txtWORKER_ORDER1.CanGrow = false;
            this.txtWORKER_ORDER1.DataField = "WORKER_ORDER1";
            this.txtWORKER_ORDER1.Height = 0.1811024F;
            this.txtWORKER_ORDER1.Left = 4.552669F;
            this.txtWORKER_ORDER1.Name = "txtWORKER_ORDER1";
            this.txtWORKER_ORDER1.OutputFormat = resources.GetString("txtWORKER_ORDER1.OutputFormat");
            this.txtWORKER_ORDER1.Style = "background-color: Transparent; font-size: 9.75pt; font-weight: bold; text-align: " +
    "center; vertical-align: middle";
            this.txtWORKER_ORDER1.Text = "WORKER_ORDER1";
            this.txtWORKER_ORDER1.Top = 1.677803F;
            this.txtWORKER_ORDER1.Width = 0.9145669F;
            // 
            // label1
            // 
            this.label1.Height = 0.1562992F;
            this.label1.HyperLink = null;
            this.label1.Left = 0.2444137F;
            this.label1.Name = "label1";
            this.label1.Style = "font-family: Arial; font-size: 6.75pt";
            this.label1.Text = "Line";
            this.label1.Top = 0.417567F;
            this.label1.Width = 0.9582678F;
            // 
            // label2
            // 
            this.label2.Height = 0.1562992F;
            this.label2.HyperLink = null;
            this.label2.Left = 0.2444137F;
            this.label2.Name = "label2";
            this.label2.Style = "font-family: Arial; font-size: 6.75pt";
            this.label2.Text = "Qty";
            this.label2.Top = 0.890008F;
            this.label2.Width = 0.958268F;
            // 
            // label3
            // 
            this.label3.Height = 0.1562992F;
            this.label3.HyperLink = null;
            this.label3.Left = 0.2444137F;
            this.label3.Name = "label3";
            this.label3.Style = "font-size: 6.75pt";
            this.label3.Text = "Made by";
            this.label3.Top = 1.409693F;
            this.label3.Width = 0.958268F;
            // 
            // label4
            // 
            this.label4.Height = 0.1562992F;
            this.label4.HyperLink = null;
            this.label4.Left = 0.2444137F;
            this.label4.Name = "label4";
            this.label4.Style = "font-family: Arial; font-size: 6.75pt";
            this.label4.Text = "Carrier ID";
            this.label4.Top = 1.964811F;
            this.label4.Width = 0.958268F;
            // 
            // label5
            // 
            this.label5.Height = 0.1562992F;
            this.label5.HyperLink = null;
            this.label5.Left = 0.2562245F;
            this.label5.Name = "label5";
            this.label5.Style = "font-family: Arial; font-size: 6.75pt";
            this.label5.Text = "To Locator Group";
            this.label5.Top = 2.472685F;
            this.label5.Width = 0.958268F;
            // 
            // label6
            // 
            this.label6.Height = 0.1562992F;
            this.label6.HyperLink = null;
            this.label6.Left = 1.363311F;
            this.label6.Name = "label6";
            this.label6.Style = "font-family: Arial; font-size: 6.75pt";
            this.label6.Text = "Seq No";
            this.label6.Top = 0.3923701F;
            this.label6.Width = 0.958268F;
            // 
            // label7
            // 
            this.label7.Height = 0.1562992F;
            this.label7.HyperLink = null;
            this.label7.Left = 1.371184F;
            this.label7.Name = "label7";
            this.label7.Style = "font-family: Arial; font-size: 6.75pt";
            this.label7.Text = "Description";
            this.label7.Top = 0.8884332F;
            this.label7.Width = 0.958268F;
            // 
            // label8
            // 
            this.label8.Height = 0.1562992F;
            this.label8.HyperLink = null;
            this.label8.Left = 1.371184F;
            this.label8.Name = "label8";
            this.label8.Style = "font-family: Arial; font-size: 6.75pt";
            this.label8.Text = "Part No";
            this.label8.Top = 1.400244F;
            this.label8.Width = 0.958268F;
            // 
            // label9
            // 
            this.label9.Height = 0.1562992F;
            this.label9.HyperLink = null;
            this.label9.Left = 1.375121F;
            this.label9.Name = "label9";
            this.label9.Style = "font-family: Arial; font-size: 6.75pt";
            this.label9.Text = "PST";
            this.label9.Top = 2.478984F;
            this.label9.Width = 0.958268F;
            // 
            // label10
            // 
            this.label10.Height = 0.1850394F;
            this.label10.HyperLink = null;
            this.label10.Left = 2.743232F;
            this.label10.Name = "label10";
            this.label10.Style = "font-size: 9.75pt; font-weight: bold; text-align: center";
            this.label10.Text = "Qty";
            this.label10.Top = 1.427016F;
            this.label10.Width = 0.3996062F;
            // 
            // label12
            // 
            this.label12.Height = 0.1811024F;
            this.label12.HyperLink = null;
            this.label12.Left = 3.208184F;
            this.label12.Name = "label12";
            this.label12.Style = "font-size: 9.75pt; font-weight: bold; text-align: center";
            this.label12.Text = "Model.Suffix";
            this.label12.Top = 1.423079F;
            this.label12.Width = 1.315355F;
            // 
            // label13
            // 
            this.label13.Height = 0.1811024F;
            this.label13.HyperLink = null;
            this.label13.Left = 4.552669F;
            this.label13.Name = "label13";
            this.label13.Style = "font-size: 9.75pt; font-weight: bold; text-align: center";
            this.label13.Text = "W/O";
            this.label13.Top = 1.419142F;
            this.label13.Width = 0.9145669F;
            // 
            // label15
            // 
            this.label15.Height = 0.202362F;
            this.label15.HyperLink = null;
            this.label15.Left = 0.3318151F;
            this.label15.Name = "label15";
            this.label15.Style = "font-size: 11.25pt; font-weight: normal; vertical-align: middle";
            this.label15.Text = "Printed Date : ";
            this.label15.Top = 3.16363F;
            this.label15.Width = 1.140157F;
            // 
            // txtPrintedDate
            // 
            this.txtPrintedDate.CanGrow = false;
            this.txtPrintedDate.DataField = "PRINTED_DATE";
            this.txtPrintedDate.Height = 0.222047F;
            this.txtPrintedDate.Left = 1.41961F;
            this.txtPrintedDate.Name = "txtPrintedDate";
            this.txtPrintedDate.Style = "background-color: Transparent; font-size: 11.25pt; font-weight: normal; text-alig" +
    "n: left; vertical-align: middle";
            this.txtPrintedDate.Text = "PRINTED_DATE";
            this.txtPrintedDate.Top = 3.16363F;
            this.txtPrintedDate.Width = 2.28937F;
            // 
            // label17
            // 
            this.label17.Height = 0.202362F;
            this.label17.HyperLink = null;
            this.label17.Left = 4.513692F;
            this.label17.Name = "label17";
            this.label17.Style = "font-family: Arial; font-size: 9pt; font-weight: normal; vertical-align: middle";
            this.label17.Text = "Printed by MCS";
            this.label17.Top = 3.578591F;
            this.label17.Width = 1.014961F;
            // 
            // txtWO_QUANTITY2
            // 
            this.txtWO_QUANTITY2.CanGrow = false;
            this.txtWO_QUANTITY2.DataField = "WO_QUANTITY2";
            this.txtWO_QUANTITY2.Height = 0.1811024F;
            this.txtWO_QUANTITY2.Left = 2.743232F;
            this.txtWO_QUANTITY2.Name = "txtWO_QUANTITY2";
            this.txtWO_QUANTITY2.OutputFormat = resources.GetString("txtWO_QUANTITY2.OutputFormat");
            this.txtWO_QUANTITY2.Style = "background-color: Transparent; font-size: 9.75pt; font-weight: bold; text-align: " +
    "center; vertical-align: middle";
            this.txtWO_QUANTITY2.Text = "WO_QUANTITY2";
            this.txtWO_QUANTITY2.Top = 1.950638F;
            this.txtWO_QUANTITY2.Width = 0.3996062F;
            // 
            // textBox4
            // 
            this.textBox4.CanGrow = false;
            this.textBox4.DataField = "MODEL_SUFFIX2";
            this.textBox4.Height = 0.1811024F;
            this.textBox4.Left = 3.208184F;
            this.textBox4.Name = "textBox4";
            this.textBox4.OutputFormat = resources.GetString("textBox4.OutputFormat");
            this.textBox4.Style = "background-color: Transparent; font-size: 8pt; font-weight: bold; text-align: cen" +
    "ter; vertical-align: middle; ddo-char-set: 1";
            this.textBox4.Text = "MODEL_SUFFIX2";
            this.textBox4.Top = 1.958512F;
            this.textBox4.Width = 1.315355F;
            // 
            // textBox5
            // 
            this.textBox5.CanGrow = false;
            this.textBox5.DataField = "WORKER_ORDER2";
            this.textBox5.Height = 0.1811024F;
            this.textBox5.Left = 4.552669F;
            this.textBox5.Name = "textBox5";
            this.textBox5.OutputFormat = resources.GetString("textBox5.OutputFormat");
            this.textBox5.Style = "background-color: Transparent; font-size: 9.75pt; font-weight: bold; text-align: " +
    "center; vertical-align: middle";
            this.textBox5.Text = "WORKER_ORDER2";
            this.textBox5.Top = 1.942764F;
            this.textBox5.Width = 0.9145669F;
            // 
            // txtWO_QUANTITY3
            // 
            this.txtWO_QUANTITY3.CanGrow = false;
            this.txtWO_QUANTITY3.DataField = "WO_QUANTITY3";
            this.txtWO_QUANTITY3.Height = 0.1811024F;
            this.txtWO_QUANTITY3.Left = 2.743232F;
            this.txtWO_QUANTITY3.Name = "txtWO_QUANTITY3";
            this.txtWO_QUANTITY3.OutputFormat = resources.GetString("txtWO_QUANTITY3.OutputFormat");
            this.txtWO_QUANTITY3.Style = "background-color: Transparent; font-size: 9.75pt; font-weight: bold; text-align: " +
    "center; vertical-align: middle";
            this.txtWO_QUANTITY3.Text = "WO_QUANTITY3";
            this.txtWO_QUANTITY3.Top = 2.206543F;
            this.txtWO_QUANTITY3.Width = 0.3996062F;
            // 
            // textBox9
            // 
            this.textBox9.CanGrow = false;
            this.textBox9.DataField = "MODEL_SUFFIX3";
            this.textBox9.Height = 0.1811024F;
            this.textBox9.Left = 3.208184F;
            this.textBox9.Name = "textBox9";
            this.textBox9.OutputFormat = resources.GetString("textBox9.OutputFormat");
            this.textBox9.Style = "background-color: Transparent; font-size: 8pt; font-weight: bold; text-align: cen" +
    "ter; vertical-align: middle; ddo-char-set: 1";
            this.textBox9.Text = "MODEL_SUFFIX3";
            this.textBox9.Top = 2.21048F;
            this.textBox9.Width = 1.315355F;
            // 
            // textBox10
            // 
            this.textBox10.CanGrow = false;
            this.textBox10.DataField = "WORKER_ORDER3";
            this.textBox10.Height = 0.1811024F;
            this.textBox10.Left = 4.552669F;
            this.textBox10.Name = "textBox10";
            this.textBox10.OutputFormat = resources.GetString("textBox10.OutputFormat");
            this.textBox10.Style = "background-color: Transparent; font-size: 9.75pt; font-weight: bold; text-align: " +
    "center; vertical-align: middle";
            this.textBox10.Text = "WORKER_ORDER3";
            this.textBox10.Top = 2.202606F;
            this.textBox10.Width = 0.9145669F;
            // 
            // txtWO_QUANTITY4
            // 
            this.txtWO_QUANTITY4.CanGrow = false;
            this.txtWO_QUANTITY4.DataField = "WO_QUANTITY4";
            this.txtWO_QUANTITY4.Height = 0.1811024F;
            this.txtWO_QUANTITY4.Left = 2.743232F;
            this.txtWO_QUANTITY4.Name = "txtWO_QUANTITY4";
            this.txtWO_QUANTITY4.OutputFormat = resources.GetString("txtWO_QUANTITY4.OutputFormat");
            this.txtWO_QUANTITY4.Style = "background-color: Transparent; font-size: 9.75pt; font-weight: bold; text-align: " +
    "center; vertical-align: middle";
            this.txtWO_QUANTITY4.Text = "WO_QUANTITY3";
            this.txtWO_QUANTITY4.Top = 2.466386F;
            this.txtWO_QUANTITY4.Width = 0.3996062F;
            // 
            // textBox14
            // 
            this.textBox14.CanGrow = false;
            this.textBox14.DataField = "MODEL_SUFFIX4";
            this.textBox14.Height = 0.1811024F;
            this.textBox14.Left = 3.208184F;
            this.textBox14.Name = "textBox14";
            this.textBox14.OutputFormat = resources.GetString("textBox14.OutputFormat");
            this.textBox14.Style = "background-color: Transparent; font-size: 8pt; font-weight: bold; text-align: cen" +
    "ter; vertical-align: middle; ddo-char-set: 1";
            this.textBox14.Text = "MODEL_SUFFIX4";
            this.textBox14.Top = 2.470323F;
            this.textBox14.Width = 1.315355F;
            // 
            // textBox15
            // 
            this.textBox15.CanGrow = false;
            this.textBox15.DataField = "WORKER_ORDER4";
            this.textBox15.Height = 0.1811024F;
            this.textBox15.Left = 4.552669F;
            this.textBox15.Name = "textBox15";
            this.textBox15.OutputFormat = resources.GetString("textBox15.OutputFormat");
            this.textBox15.Style = "background-color: Transparent; font-size: 9.75pt; font-weight: bold; text-align: " +
    "center; vertical-align: middle";
            this.textBox15.Text = "WORKER_ORDER4";
            this.textBox15.Top = 2.454575F;
            this.textBox15.Width = 0.9145669F;
            // 
            // txtWO_QUANTITY5
            // 
            this.txtWO_QUANTITY5.CanGrow = false;
            this.txtWO_QUANTITY5.DataField = "WO_QUANTITY5";
            this.txtWO_QUANTITY5.Height = 0.1811026F;
            this.txtWO_QUANTITY5.Left = 2.743232F;
            this.txtWO_QUANTITY5.Name = "txtWO_QUANTITY5";
            this.txtWO_QUANTITY5.OutputFormat = resources.GetString("txtWO_QUANTITY5.OutputFormat");
            this.txtWO_QUANTITY5.Style = "background-color: Transparent; font-size: 9.75pt; font-weight: bold; text-align: " +
    "center; vertical-align: middle";
            this.txtWO_QUANTITY5.Text = "WO_QUANTITY3";
            this.txtWO_QUANTITY5.Top = 2.753F;
            this.txtWO_QUANTITY5.Width = 0.3996062F;
            // 
            // textBox19
            // 
            this.textBox19.CanGrow = false;
            this.textBox19.DataField = "MODEL_SUFFIX5";
            this.textBox19.Height = 0.1811024F;
            this.textBox19.Left = 3.208184F;
            this.textBox19.Name = "textBox19";
            this.textBox19.OutputFormat = resources.GetString("textBox19.OutputFormat");
            this.textBox19.Style = "background-color: Transparent; font-size: 8pt; font-weight: bold; text-align: cen" +
    "ter; vertical-align: middle; ddo-char-set: 1";
            this.textBox19.Text = "MODEL_SUFFIX5";
            this.textBox19.Top = 2.745126F;
            this.textBox19.Width = 1.315355F;
            // 
            // textBox20
            // 
            this.textBox20.CanGrow = false;
            this.textBox20.DataField = "WORKER_ORDER5";
            this.textBox20.Height = 0.1811024F;
            this.textBox20.Left = 4.552669F;
            this.textBox20.Name = "textBox20";
            this.textBox20.OutputFormat = resources.GetString("textBox20.OutputFormat");
            this.textBox20.Style = "background-color: Transparent; font-size: 9.75pt; font-weight: bold; text-align: " +
    "center; vertical-align: middle";
            this.textBox20.Text = "WORKER_ORDER5";
            this.textBox20.Top = 2.737252F;
            this.textBox20.Width = 0.9145669F;
            // 
            // barcode
            // 
            this.barcode.BackColor = System.Drawing.Color.White;
            this.barcode.DataField = "QRCODE_VALUE";
            this.barcode.Font = new System.Drawing.Font("Courier New", 8F);
            this.barcode.Height = 0.9319445F;
            this.barcode.Left = 4.557F;
            this.barcode.Name = "barcode";
            this.barcode.QuietZoneBottom = 0F;
            this.barcode.QuietZoneLeft = 0F;
            this.barcode.QuietZoneRight = 0F;
            this.barcode.QuietZoneTop = 0F;
            this.barcode.Style = GrapeCity.ActiveReports.SectionReportModel.BarCodeStyle.QRCode;
            this.barcode.Text = "barcod";
            this.barcode.Top = 0.403F;
            this.barcode.Width = 0.9326389F;
            // 
            // txtLOCATOR_GROUP
            // 
            this.txtLOCATOR_GROUP.DataField = "LOCATOR_GROUP";
            this.txtLOCATOR_GROUP.Height = 0.2468504F;
            this.txtLOCATOR_GROUP.Left = 0.2759097F;
            this.txtLOCATOR_GROUP.Name = "txtLOCATOR_GROUP";
            this.txtLOCATOR_GROUP.Style = "background-color: Transparent; font-size: 12pt; font-weight: bold; text-align: ce" +
    "nter; vertical-align: middle";
            this.txtLOCATOR_GROUP.Text = "LOCATOR_GROUP";
            this.txtLOCATOR_GROUP.Top = 2.656543F;
            this.txtLOCATOR_GROUP.Width = 1.064173F;
            // 
            // txtLINE
            // 
            this.txtLINE.DataField = "LINE";
            this.txtLINE.Height = 0.2468504F;
            this.txtLINE.Left = 0.2798393F;
            this.txtLINE.Name = "txtLINE";
            this.txtLINE.Style = "background-color: Transparent; font-size: 12pt; font-weight: bold; text-align: ce" +
    "nter; vertical-align: middle";
            this.txtLINE.Text = "LINE";
            this.txtLINE.Top = 0.5608742F;
            this.txtLINE.Width = 1.001575F;
            // 
            // txtPART_NO
            // 
            this.txtPART_NO.DataField = "PART_NO";
            this.txtPART_NO.Height = 0.2570866F;
            this.txtPART_NO.Left = 1.373153F;
            this.txtPART_NO.Name = "txtPART_NO";
            this.txtPART_NO.Style = "background-color: Transparent; font-size: 12pt; font-weight: bold; text-align: ce" +
    "nter; vertical-align: middle";
            this.txtPART_NO.Text = "PART_NO";
            this.txtPART_NO.Top = 1.576228F;
            this.txtPART_NO.Width = 1.246457F;
            // 
            // line1
            // 
            this.line1.Height = 0F;
            this.line1.Left = 0.2333902F;
            this.line1.LineWeight = 1.5F;
            this.line1.Name = "line1";
            this.line1.Top = 0.8770158F;
            this.line1.Width = 4.293687F;
            this.line1.X1 = 0.2333902F;
            this.line1.X2 = 4.527078F;
            this.line1.Y1 = 0.8770158F;
            this.line1.Y2 = 0.8770158F;
            // 
            // shape1
            // 
            this.shape1.Height = 3.181102F;
            this.shape1.Left = 0.2089804F;
            this.shape1.Name = "shape1";
            this.shape1.RoundingRadius = new GrapeCity.ActiveReports.Controls.CornersRadius(10F, null, null, null, null);
            this.shape1.Top = 0.3415828F;
            this.shape1.Width = 5.339764F;
            // 
            // shape2
            // 
            this.shape2.Height = 3.120867F;
            this.shape2.Left = 0.2310279F;
            this.shape2.Name = "shape2";
            this.shape2.RoundingRadius = new GrapeCity.ActiveReports.Controls.CornersRadius(10F, null, null, null, null);
            this.shape2.Top = 0.3648112F;
            this.shape2.Width = 5.290158F;
            // 
            // line2
            // 
            this.line2.Height = 2.384186E-07F;
            this.line2.Left = 0.2333902F;
            this.line2.LineWeight = 1.5F;
            this.line2.Name = "line2";
            this.line2.Top = 1.364811F;
            this.line2.Width = 5.294475F;
            this.line2.X1 = 0.2333902F;
            this.line2.X2 = 5.527865F;
            this.line2.Y1 = 1.364811F;
            this.line2.Y2 = 1.364811F;
            // 
            // line3
            // 
            this.line3.Height = 4.768372E-07F;
            this.line3.Left = 0.2337835F;
            this.line3.LineWeight = 1.5F;
            this.line3.Name = "line3";
            this.line3.Top = 1.920716F;
            this.line3.Width = 5.294089F;
            this.line3.X1 = 0.2337835F;
            this.line3.X2 = 5.527873F;
            this.line3.Y1 = 1.920716F;
            this.line3.Y2 = 1.920717F;
            // 
            // line4
            // 
            this.line4.Height = 0F;
            this.line4.Left = 0.2314213F;
            this.line4.LineWeight = 1.5F;
            this.line4.Name = "line4";
            this.line4.Top = 2.433315F;
            this.line4.Width = 5.297625F;
            this.line4.X1 = 0.2314213F;
            this.line4.X2 = 5.529046F;
            this.line4.Y1 = 2.433315F;
            this.line4.Y2 = 2.433315F;
            // 
            // line5
            // 
            this.line5.Height = 4.768372E-07F;
            this.line5.Left = 0.2333902F;
            this.line5.LineWeight = 1.5F;
            this.line5.Name = "line5";
            this.line5.Top = 2.983708F;
            this.line5.Width = 5.294475F;
            this.line5.X1 = 0.2333902F;
            this.line5.X2 = 5.527865F;
            this.line5.Y1 = 2.983708F;
            this.line5.Y2 = 2.983709F;
            // 
            // line6
            // 
            this.line6.Height = 2.615354F;
            this.line6.Left = 4.524716F;
            this.line6.LineWeight = 1.5F;
            this.line6.Name = "line6";
            this.line6.Top = 0.3652049F;
            this.line6.Width = 0F;
            this.line6.X1 = 4.524716F;
            this.line6.X2 = 4.524716F;
            this.line6.Y1 = 0.3652049F;
            this.line6.Y2 = 2.980559F;
            // 
            // line8
            // 
            this.line8.Height = 1.613779F;
            this.line8.Left = 2.707799F;
            this.line8.LineWeight = 1.5F;
            this.line8.Name = "line8";
            this.line8.Top = 1.365992F;
            this.line8.Width = 0F;
            this.line8.X1 = 2.707799F;
            this.line8.X2 = 2.707799F;
            this.line8.Y1 = 1.365992F;
            this.line8.Y2 = 2.979772F;
            // 
            // line9
            // 
            this.line9.Height = 1.613386F;
            this.line9.Left = 3.185746F;
            this.line9.LineWeight = 1.5F;
            this.line9.Name = "line9";
            this.line9.Top = 1.366386F;
            this.line9.Width = 0F;
            this.line9.X1 = 3.185746F;
            this.line9.X2 = 3.185746F;
            this.line9.Y1 = 1.366386F;
            this.line9.Y2 = 2.979772F;
            // 
            // line10
            // 
            this.line10.Height = 2.61811F;
            this.line10.Left = 1.333783F;
            this.line10.LineWeight = 1.5F;
            this.line10.Name = "line10";
            this.line10.Top = 0.3648112F;
            this.line10.Width = 0F;
            this.line10.X1 = 1.333783F;
            this.line10.X2 = 1.333783F;
            this.line10.Y1 = 0.3648112F;
            this.line10.Y2 = 2.982921F;
            // 
            // line11
            // 
            this.line11.Height = 0F;
            this.line11.Left = 2.711343F;
            this.line11.LineWeight = 1.5F;
            this.line11.Name = "line11";
            this.line11.Top = 2.164811F;
            this.line11.Width = 2.81653F;
            this.line11.X1 = 2.711343F;
            this.line11.X2 = 5.527873F;
            this.line11.Y1 = 2.164811F;
            this.line11.Y2 = 2.164811F;
            // 
            // line12
            // 
            this.line12.Height = 4.768372E-07F;
            this.line12.Left = 2.713704F;
            this.line12.LineWeight = 1.5F;
            this.line12.Name = "line12";
            this.line12.Top = 2.697094F;
            this.line12.Width = 2.810232F;
            this.line12.X1 = 2.713704F;
            this.line12.X2 = 5.523936F;
            this.line12.Y1 = 2.697094F;
            this.line12.Y2 = 2.697095F;
            // 
            // line13
            // 
            this.line13.Height = 0F;
            this.line13.Left = 2.715279F;
            this.line13.LineWeight = 1.5F;
            this.line13.Name = "line13";
            this.line13.Top = 1.641976F;
            this.line13.Width = 2.812594F;
            this.line13.X1 = 2.715279F;
            this.line13.X2 = 5.527873F;
            this.line13.Y1 = 1.641976F;
            this.line13.Y2 = 1.641976F;
            // 
            // txtSheetID
            // 
            this.txtSheetID.CanGrow = false;
            this.txtSheetID.DataField = "SHEET_ID";
            this.txtSheetID.Height = 0.222047F;
            this.txtSheetID.Left = 3.333377F;
            this.txtSheetID.Name = "txtSheetID";
            this.txtSheetID.Style = "background-color: Transparent; font-size: 11.25pt; font-weight: normal; text-alig" +
    "n: center; vertical-align: middle";
            this.txtSheetID.Text = "SHEET_ID";
            this.txtSheetID.Top = 3.151819F;
            this.txtSheetID.Width = 2.214567F;
            // 
            // txtPST
            // 
            this.txtPST.CanGrow = false;
            this.txtPST.DataField = "PST";
            this.txtPST.Height = 0.3692912F;
            this.txtPST.Left = 1.357798F;
            this.txtPST.Name = "txtPST";
            this.txtPST.Style = "background-color: Transparent; font-family: Arial; font-size: 10pt; font-weight: " +
    "bold; text-align: center; vertical-align: top; ddo-char-set: 1";
            this.txtPST.Text = "2019-01-30 PM  12:12:11";
            this.txtPST.Top = 2.571504F;
            this.txtPST.Width = 1.35748F;
            // 
            // Detail
            // 
            this.Detail.ColumnCount = 2;
            this.Detail.ColumnDirection = GrapeCity.ActiveReports.SectionReportModel.ColumnDirection.AcrossDown;
            this.Detail.Controls.AddRange(new GrapeCity.ActiveReports.SectionReportModel.ARControl[] {
            this.shape1,
            this.shape2,
            this.txtTOTAL_QUANTITY,
            this.txtCARRIER_ID,
            this.txtMADE_BY,
            this.txtDESCRIPTION,
            this.txtINSPECTION_FLAG,
            this.txtWO_QUANTITY1,
            this.txtTOTAL_SEQ_NO,
            this.txtMODEL_SUFFIX1,
            this.txtWORKER_ORDER1,
            this.label1,
            this.label2,
            this.label3,
            this.label4,
            this.label5,
            this.label6,
            this.label7,
            this.label8,
            this.label9,
            this.label10,
            this.label12,
            this.label13,
            this.label15,
            this.txtPrintedDate,
            this.label17,
            this.txtWO_QUANTITY2,
            this.textBox4,
            this.textBox5,
            this.txtWO_QUANTITY3,
            this.textBox9,
            this.textBox10,
            this.txtWO_QUANTITY4,
            this.textBox14,
            this.textBox15,
            this.txtWO_QUANTITY5,
            this.textBox19,
            this.textBox20,
            this.barcode,
            this.txtLOCATOR_GROUP,
            this.txtLINE,
            this.txtPART_NO,
            this.line1,
            this.line2,
            this.line3,
            this.line4,
            this.line5,
            this.line6,
            this.line8,
            this.line9,
            this.line10,
            this.line11,
            this.line12,
            this.line13,
            this.txtSheetID,
            this.txtPST});
            this.Detail.Height = 4.114616F;
            this.Detail.Name = "Detail";
            // 
            // OfflinePrintBoard_GsrmSize
            // 
            this.MasterReport = false;
            this.PageSettings.Margins.Bottom = 0F;
            this.PageSettings.Margins.Left = 0.09448819F;
            this.PageSettings.Margins.Right = 0.09448819F;
            this.PageSettings.Margins.Top = 0.03F;
            this.PageSettings.Orientation = GrapeCity.ActiveReports.Document.Section.PageOrientation.Landscape;
            this.PageSettings.PaperHeight = 11F;
            this.PageSettings.PaperWidth = 8.5F;
            this.PrintWidth = 11.46189F;
            this.Sections.Add(this.Detail);
            this.StyleSheet.Add(new DDCssLib.StyleSheetRule("font-family: Arial; font-style: normal; text-decoration: none; font-weight: norma" +
            "l; font-size: 10pt; color: Black; ddo-char-set: 186", "Normal"));
            this.StyleSheet.Add(new DDCssLib.StyleSheetRule("font-family: Arial; font-size: 16pt; font-style: normal; font-weight: bold; ddo-c" +
            "har-set: 186", "Heading1", "Normal"));
            this.StyleSheet.Add(new DDCssLib.StyleSheetRule("font-family: Times New Roman; font-size: 14pt; font-style: italic; font-weight: b" +
            "old; ddo-char-set: 186", "Heading2", "Normal"));
            this.StyleSheet.Add(new DDCssLib.StyleSheetRule("font-family: Arial; font-size: 13pt; font-style: normal; font-weight: bold; ddo-c" +
            "har-set: 186", "Heading3", "Normal"));
            ((System.ComponentModel.ISupportInitialize)(this.txtTOTAL_QUANTITY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCARRIER_ID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMADE_BY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDESCRIPTION)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtINSPECTION_FLAG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWO_QUANTITY1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTOTAL_SEQ_NO)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMODEL_SUFFIX1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWORKER_ORDER1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPrintedDate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.label17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWO_QUANTITY2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWO_QUANTITY3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWO_QUANTITY4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWO_QUANTITY5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLOCATOR_GROUP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLINE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPART_NO)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSheetID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPST)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

		}
		#endregion
		private TextBox txtTOTAL_SEQ_NO;
		private Detail Detail;
		private TextBox txtTOTAL_QUANTITY;
		private TextBox txtCARRIER_ID;
		private TextBox txtMADE_BY;
		private TextBox txtDESCRIPTION;
		private TextBox txtINSPECTION_FLAG;
		private TextBox txtWO_QUANTITY1;
        private TextBox txtMODEL_SUFFIX1;
        private TextBox txtWORKER_ORDER1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label12;
        private Label label13;
        private Label label15;
        private TextBox txtPrintedDate;
        private Label label17;
        private TextBox txtWO_QUANTITY2;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox txtWO_QUANTITY3;
        private TextBox textBox9;
        private TextBox textBox10;
        private TextBox txtWO_QUANTITY4;
        private TextBox textBox14;
        private TextBox textBox15;
        private TextBox txtWO_QUANTITY5;
        private TextBox textBox19;
        private TextBox textBox20;
        private Barcode barcode;
        private TextBox txtLOCATOR_GROUP;
        private TextBox txtLINE;
        private TextBox txtPART_NO;
        private Line line1;
        private Shape shape2;
        private Shape shape1;
        private Line line2;
        private Line line3;
        private Line line4;
        private Line line5;
        private Line line6;
        private Line line8;
        private Line line9;
        private Line line10;
        private Line line11;
        private Line line12;
        private Line line13;
        private TextBox txtSheetID;
        private TextBox txtPST;
    }
}
